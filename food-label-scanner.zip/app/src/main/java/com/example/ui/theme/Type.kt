package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val CondensedDisplayFont = FontFamily.SansSerif

val Typography =
  Typography(
    displayLarge = TextStyle(
      fontFamily = CondensedDisplayFont,
      fontWeight = FontWeight.Black,
      fontSize = 32.sp,
      lineHeight = 36.sp,
      letterSpacing = (-0.5).sp,
      color = CharcoalText
    ),
    displayMedium = TextStyle(
      fontFamily = CondensedDisplayFont,
      fontWeight = FontWeight.Black,
      fontSize = 28.sp,
      lineHeight = 32.sp,
      letterSpacing = (-0.3).sp,
      color = CharcoalText
    ),
    titleLarge = TextStyle(
      fontFamily = CondensedDisplayFont,
      fontWeight = FontWeight.Bold,
      fontSize = 22.sp,
      lineHeight = 26.sp,
      color = CharcoalText
    ),
    bodyLarge = TextStyle(
      fontFamily = FontFamily.SansSerif,
      fontWeight = FontWeight.Normal,
      fontSize = 15.sp,
      lineHeight = 22.sp,
      letterSpacing = 0.2.sp,
      color = CharcoalMuted
    ),
    bodyMedium = TextStyle(
      fontFamily = FontFamily.SansSerif,
      fontWeight = FontWeight.Normal,
      fontSize = 14.sp,
      lineHeight = 20.sp,
      color = CharcoalText
    ),
    labelLarge = TextStyle(
      fontFamily = CondensedDisplayFont,
      fontWeight = FontWeight.Bold,
      fontSize = 18.sp,
      lineHeight = 22.sp,
      color = CharcoalText
    )
  )

