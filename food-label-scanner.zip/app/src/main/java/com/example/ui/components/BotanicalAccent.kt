package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun BotanicalAccent(
    modifier: Modifier = Modifier,
    color: Color = Color(0xFFC0B8A8)
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val strokeWidth = 1.8f

        // Branch 1 - Main leaf stem curving from bottom right up
        val path1 = Path().apply {
            moveTo(w * 0.95f, h)
            cubicTo(w * 0.90f, h * 0.82f, w * 0.70f, h * 0.75f, w * 0.52f, h * 0.85f)
        }
        drawPath(path = path1, color = color, style = Stroke(width = strokeWidth))

        // Leaf 1
        val leaf1 = Path().apply {
            moveTo(w * 0.75f, h * 0.81f)
            quadraticTo(w * 0.68f, h * 0.80f, w * 0.65f, h * 0.86f)
            quadraticTo(w * 0.70f, h * 0.88f, w * 0.75f, h * 0.81f)
        }
        drawPath(path = leaf1, color = color, style = Stroke(width = strokeWidth))

        // Leaf 2
        val leaf2 = Path().apply {
            moveTo(w * 0.82f, h * 0.85f)
            quadraticTo(w * 0.78f, h * 0.92f, w * 0.82f, h * 0.96f)
            quadraticTo(w * 0.88f, h * 0.90f, w * 0.82f, h * 0.85f)
        }
        drawPath(path = leaf2, color = color, style = Stroke(width = strokeWidth))

        // Branch 2 - Tall flower stem extending towards top right corner
        val path2 = Path().apply {
            moveTo(w * 0.92f, h * 0.95f)
            cubicTo(w * 0.88f, h * 0.72f, w * 0.78f, h * 0.68f, w * 0.88f, h * 0.65f)
        }
        drawPath(path = path2, color = color, style = Stroke(width = strokeWidth))

        // Flower heads / seed pods at top of Branch 2
        val flowerTop = Offset(w * 0.88f, h * 0.65f)
        for (angle in listOf(-60f, -30f, 0f, 30f, 60f)) {
            val rad = Math.toRadians(angle.toDouble())
            val endX = flowerTop.x + (25 * Math.sin(rad)).toFloat()
            val endY = flowerTop.y - (30 * Math.cos(rad)).toFloat()
            drawLine(
                color = color,
                start = flowerTop,
                end = Offset(endX, endY),
                strokeWidth = strokeWidth
            )
            drawCircle(
                color = color,
                radius = 2.5f,
                center = Offset(endX, endY)
            )
        }

        // Branch 3 - Lower leaf branch
        val path3 = Path().apply {
            moveTo(w * 0.88f, h)
            cubicTo(w * 0.70f, h * 0.94f, w * 0.55f, h * 0.90f, w * 0.48f, h * 0.84f)
        }
        drawPath(path = path3, color = color, style = Stroke(width = strokeWidth))

        // Additional leaves along branch 3
        val leaf3 = Path().apply {
            moveTo(w * 0.60f, h * 0.90f)
            quadraticTo(w * 0.52f, h * 0.93f, w * 0.50f, h * 0.88f)
            quadraticTo(w * 0.58f, h * 0.86f, w * 0.60f, h * 0.90f)
        }
        drawPath(path = leaf3, color = color, style = Stroke(width = strokeWidth))
    }
}
