package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FoodLabelExtraction
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CharcoalMuted
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.CondensedDisplayFont
import com.example.ui.theme.TerracottaAccent

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PersonalizationScreen(
    userLanguage: String,
    extraction: FoodLabelExtraction,
    onScanNext: () -> Unit,
    onChangeLanguage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isHindi = userLanguage == "hi"

    val title = if (isHindi) "निष्कर्षण विवरण" else "LABEL EXTRACTED"
    val goalsTitle = if (isHindi) "अपने स्वास्थ्य लक्ष्य चुनें" else "Select Personalization Goals"

    val goalsList = if (isHindi) listOf(
        "उच्च प्रोटीन", "कम चीनी", "कम सोडियम", "एलर्जी-मुक्त", "ग्लूटेन फ्री"
    ) else listOf(
        "High Protein", "Low Sugar", "Low Sodium", "Nut Free", "Gluten Free"
    )

    val selectedGoals = remember { mutableStateListOf<String>() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                fontFamily = CondensedDisplayFont,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                color = CharcoalText
            )

            Row {
                IconButton(onClick = onChangeLanguage) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Language",
                        tint = CharcoalText
                    )
                }
                IconButton(onClick = onScanNext) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "New Scan",
                        tint = CharcoalText
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Product Summary Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = extraction.front_of_pack.brand_name.ifEmpty { "Product Label" },
                        fontFamily = CondensedDisplayFont,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TerracottaAccent
                    )

                    // Confidence Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFE8F5E9))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${extraction.extraction_confidence.uppercase()} CONFIDENCE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = extraction.front_of_pack.product_name.ifEmpty { "Scanned Food Item" },
                    fontFamily = CondensedDisplayFont,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    color = CharcoalText
                )

                if (extraction.front_of_pack.claims.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        extraction.front_of_pack.claims.forEach { claim ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFFF3EFE6))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = claim,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = CharcoalText
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Normalized Nutrition Facts (per 100g)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = if (isHindi) "पोषण विवरण (प्रति 100 ग्राम)" else "NUTRITION FACTS (PER 100g)",
                    fontFamily = CondensedDisplayFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = CharcoalText
                )

                Spacer(modifier = Modifier.height(12.dp))

                val n = extraction.nutrition
                NutritionRow(label = if (isHindi) "ऊर्जा (Energy)" else "Energy", value = "${n.energy_kcal} kcal")
                NutritionRow(label = if (isHindi) "कुल वसा (Total Fat)" else "Total Fat", value = "${n.total_fat_g} g")
                NutritionRow(label = if (isHindi) "संतृप्त वसा (Saturated Fat)" else "Saturated Fat", value = "${n.saturated_fat_g} g")
                NutritionRow(
                    label = if (isHindi) "ट्रांस वसा (Trans Fat)" else "Trans Fat",
                    value = if (n.trans_fat_g == null) "Not Printed (null)" else "${n.trans_fat_g} g"
                )
                NutritionRow(label = if (isHindi) "शर्करा (Sugar)" else "Total Sugars", value = "${n.sugar_g} g")
                NutritionRow(label = if (isHindi) "सोडियम (Sodium)" else "Sodium", value = "${n.sodium_mg} mg")
                NutritionRow(label = if (isHindi) "प्रोटीन (Protein)" else "Protein", value = "${n.protein_g} g")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Ingredients
        if (extraction.ingredients.raw_list.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (isHindi) "सामग्री (Ingredients)" else "INGREDIENTS",
                        fontFamily = CondensedDisplayFont,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = CharcoalText
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = extraction.ingredients.raw_list.joinToString(", "),
                        fontSize = 14.sp,
                        color = CharcoalMuted,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Personalization Goal Selector
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = goalsTitle,
                    fontFamily = CondensedDisplayFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = CharcoalText
                )

                Spacer(modifier = Modifier.height(12.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    goalsList.forEach { goal ->
                        val isSelected = selectedGoals.contains(goal)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) TerracottaAccent else Color(0xFFF3EFE6))
                                .clickable {
                                    if (isSelected) selectedGoals.remove(goal) else selectedGoals.add(goal)
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                }
                                Text(
                                    text = goal,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else CharcoalText
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Action Button: Scan Next Product
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(TerracottaAccent)
                .clickable { onScanNext() }
                .testTag("scan_another_button"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (isHindi) "दूसरा पैकेट स्कैन करें" else "SCAN ANOTHER PRODUCT",
                fontFamily = CondensedDisplayFont,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color.White
            )
        }
    }
}

@Composable
private fun NutritionRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 14.sp,
            color = CharcoalMuted
        )
        Text(
            text = value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = CharcoalText
        )
    }
}
