package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CameraViewfinder
import com.example.ui.components.CaptureProgressIndicator
import com.example.ui.components.SamplePackGenerator
import com.example.ui.theme.CharcoalMuted
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.CondensedDisplayFont
import com.example.ui.theme.TerracottaAccent

@Composable
fun CapturePanelScreen(
    userLanguage: String,
    onPanelCaptured: (Bitmap) -> Unit,
    modifier: Modifier = Modifier
) {
    val sampleBitmap = remember { SamplePackGenerator.createPanelPackBitmap() }
    var useLiveCamera by remember { mutableStateOf(false) }

    val phaseText = if (userLanguage == "hi") "स्कैन चरण 02" else "SCAN PHASE 02"
    val headline = if (userLanguage == "hi") "सामग्री व पोषण तालिका" else "CAPTURE NUTRITION PANEL"
    val subtitle = if (userLanguage == "hi") "यदि संभव हो तो पूरे पैनल को फ्रेम में लाएं।" else "Position the ingredients & nutrition panel clearly within the frame."

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Header with Phase 02 label
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = phaseText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = CharcoalMuted
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = headline,
                fontFamily = CondensedDisplayFont,
                fontWeight = FontWeight.Black,
                fontSize = 32.sp,
                lineHeight = 34.sp,
                color = CharcoalText
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Top 2-segment progress indicator (segment 2 active)
            CaptureProgressIndicator(
                activeStep = 2,
                modifier = Modifier.padding(horizontal = 0.dp, vertical = 0.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Viewfinder with Terracotta Guide Overlay
        CameraViewfinder(
            step = 2,
            sampleBitmap = sampleBitmap,
            useLiveCamera = useLiveCamera,
            onImageCaptured = { bitmap -> onPanelCaptured(bitmap) },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Subtitle instructions
        Text(
            text = subtitle,
            fontSize = 13.sp,
            color = CharcoalMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Bottom Controls: Camera shutter button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .border(1.dp, CharcoalText.copy(alpha = 0.2f), CircleShape)
                    .background(Color(0xFFF9F7F2))
                    .clickable { useLiveCamera = !useLiveCamera },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (useLiveCamera) Icons.Default.Image else Icons.Default.CameraAlt,
                    contentDescription = "Toggle Camera Source",
                    tint = CharcoalText
                )
            }

            // Terracotta Shutter button matching Artistic Flair theme
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFF9F7F2))
                    .border(6.dp, TerracottaAccent, CircleShape)
                    .padding(6.dp)
                    .clip(CircleShape)
                    .background(TerracottaAccent)
                    .clickable {
                        onPanelCaptured(sampleBitmap)
                    }
                    .testTag("capture_panel_shutter"),
                contentAlignment = Alignment.Center
            ) {}

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .border(1.dp, CharcoalText.copy(alpha = 0.2f), CircleShape)
                    .background(Color(0xFFF9F7F2)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "02",
                    fontFamily = CondensedDisplayFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TerracottaAccent
                )
            }
        }
    }
}
