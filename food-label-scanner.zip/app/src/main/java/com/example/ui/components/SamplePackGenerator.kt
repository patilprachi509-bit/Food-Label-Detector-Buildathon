package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

object SamplePackGenerator {

    fun createFrontPackBitmap(): Bitmap {
        val width = 800
        val height = 1000
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Cream background
        canvas.drawColor(Color.parseColor("#F5F0E6"))

        val paint = Paint().apply {
            isAntiAlias = true
        }

        // Bag shadow & outline
        val bagRect = RectF(120f, 150f, 680f, 880f)
        paint.color = Color.parseColor("#EAE3D2")
        canvas.drawRoundRect(bagRect, 32f, 32f, paint)

        // Bag border
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = Color.parseColor("#3A3732")
        canvas.drawRoundRect(bagRect, 32f, 32f, paint)

        // Header text
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#3A3732")
        paint.textSize = 32f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("BAKED", width / 2f, 260f, paint)

        paint.textSize = 64f
        paint.isFakeBoldText = true
        canvas.drawText("CHICKPEA PUFFS", width / 2f, 340f, paint)

        // Terracotta flavor banner
        val bannerRect = RectF(220f, 380f, 580f, 440f)
        paint.color = Color.parseColor("#C4522E")
        canvas.drawRoundRect(bannerRect, 16f, 16f, paint)

        paint.color = Color.WHITE
        paint.textSize = 32f
        canvas.drawText("SMOKY BARBEQUE", width / 2f, 422f, paint)

        // Claims row
        paint.color = Color.parseColor("#3A3732")
        paint.textSize = 24f
        canvas.drawText("PLANT PROTEIN  |  40% LESS FAT  |  GLUTEN FREE", width / 2f, 520f, paint)

        // Bowl / Snack illustration
        val bowlRect = RectF(280f, 560f, 520f, 720f)
        paint.color = Color.parseColor("#D8C8B0")
        canvas.drawOval(bowlRect, paint)

        // Net weight
        paint.textSize = 24f
        paint.isFakeBoldText = false
        canvas.drawText("NET WEIGHT 85 g", width / 2f, 820f, paint)

        return bitmap
    }

    fun createPanelPackBitmap(): Bitmap {
        val width = 800
        val height = 1000
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        canvas.drawColor(Color.parseColor("#F5F0E6"))

        val paint = Paint().apply {
            isAntiAlias = true
            color = Color.parseColor("#2B2B26")
        }

        val leftX = 80f
        var currentY = 120f

        // Ingredients section
        paint.textSize = 36f
        paint.isFakeBoldText = true
        canvas.drawText("INGREDIENTS", leftX, currentY, paint)
        currentY += 45f

        paint.textSize = 24f
        paint.isFakeBoldText = false
        val ingredientsText = listOf(
            "Chickpea flour, Rice flour, Sunflower oil,",
            "Corn starch, Tapioca starch, Sugar,",
            "Smoky barbeque seasoning (sugar, salt,",
            "tomato powder, maltodextrin, onion powder,",
            "garlic powder, smoke flavor, spices), Salt,",
            "Yeast extract, Paprika extract."
        )
        for (line in ingredientsText) {
            canvas.drawText(line, leftX, currentY, paint)
            currentY += 32f
        }

        currentY += 40f
        paint.isFakeBoldText = true
        canvas.drawText("CONTAINS: MAY CONTAIN TRACES OF NUTS.", leftX, currentY, paint)

        // Nutrition Table Box
        val tableLeft = 450f
        val tableTop = 100f
        val tableRight = 740f
        val tableBottom = 720f

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        canvas.drawRect(tableLeft, tableTop, tableRight, tableBottom, paint)

        paint.style = Paint.Style.FILL
        var tY = tableTop + 40f
        paint.textSize = 32f
        paint.isFakeBoldText = true
        canvas.drawText("NUTRITION FACTS", tableLeft + 20f, tY, paint)

        tY += 30f
        paint.textSize = 20f
        paint.isFakeBoldText = false
        canvas.drawText("Serving Size 1 oz (28 g)", tableLeft + 20f, tY, paint)
        tY += 25f
        canvas.drawText("Servings Per Pack 3", tableLeft + 20f, tY, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        tY += 15f
        canvas.drawLine(tableLeft, tY, tableRight, tY, paint)

        paint.style = Paint.Style.FILL
        tY += 35f
        paint.textSize = 28f
        paint.isFakeBoldText = true
        canvas.drawText("Calories 120", tableLeft + 20f, tY, paint)

        tY += 25f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        canvas.drawLine(tableLeft, tY, tableRight, tY, paint)

        paint.style = Paint.Style.FILL
        paint.textSize = 22f
        val items = listOf(
            "Total Fat 4 g" to "5%",
            "  Saturated Fat 0.5 g" to "3%",
            "Sodium 210 mg" to "9%",
            "Total Carbohydrate 17 g" to "6%",
            "  Total Sugars 2 g" to "4%",
            "Protein 3 g" to "6%"
        )

        for ((label, dv) in items) {
            tY += 35f
            paint.isFakeBoldText = !label.startsWith("  ")
            canvas.drawText(label, tableLeft + 20f, tY, paint)
            canvas.drawText(dv, tableRight - 60f, tY, paint)
        }

        return bitmap
    }
}
