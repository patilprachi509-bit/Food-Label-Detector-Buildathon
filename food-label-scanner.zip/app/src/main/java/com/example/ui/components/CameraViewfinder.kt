package com.example.ui.components

import android.graphics.Bitmap
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.TerracottaAccent

@Composable
fun CameraViewfinder(
    step: Int, // 1 for Front, 2 for Ingredients/Nutrition
    sampleBitmap: Bitmap,
    onImageCaptured: (Bitmap) -> Unit,
    modifier: Modifier = Modifier,
    useLiveCamera: Boolean = true
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraHardware by remember { mutableStateOf(true) }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(480.dp)
            .padding(horizontal = 24.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(Color(0xFFEDE8DD)),
        contentAlignment = Alignment.Center
    ) {
        if (useLiveCamera && hasCameraHardware) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }

                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        try {
                            val cameraProvider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build().also {
                                it.setSurfaceProvider(previewView.surfaceProvider)
                            }

                            val capture = ImageCapture.Builder()
                                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                                .build()
                            imageCapture = capture

                            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                cameraSelector,
                                preview,
                                capture
                            )
                        } catch (e: Exception) {
                            hasCameraHardware = false
                        }
                    }, ContextCompat.getMainExecutor(ctx))

                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Fallback / Sample View if camera is unavailable or sample mode active
        if (!useLiveCamera || !hasCameraHardware) {
            Image(
                bitmap = sampleBitmap.asImageBitmap(),
                contentDescription = if (step == 1) "Front of Pack" else "Ingredients Panel",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        // Terracotta Guide Overlay Frame (#C4522E)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .border(
                    width = 3.dp,
                    color = TerracottaAccent,
                    shape = RoundedCornerShape(24.dp)
                )
        ) {
            // Corner Brackets
            Box(
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.TopStart)
                    .size(24.dp)
                    .border(
                        width = 2.dp,
                        color = TerracottaAccent,
                        shape = RoundedCornerShape(topStart = 8.dp)
                    )
            )
            Box(
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.TopEnd)
                    .size(24.dp)
                    .border(
                        width = 2.dp,
                        color = TerracottaAccent,
                        shape = RoundedCornerShape(topEnd = 8.dp)
                    )
            )
            Box(
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.BottomStart)
                    .size(24.dp)
                    .border(
                        width = 2.dp,
                        color = TerracottaAccent,
                        shape = RoundedCornerShape(bottomStart = 8.dp)
                    )
            )
            Box(
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.BottomEnd)
                    .size(24.dp)
                    .border(
                        width = 2.dp,
                        color = TerracottaAccent,
                        shape = RoundedCornerShape(bottomEnd = 8.dp)
                    )
            )

            // Instruction Badge at bottom center of viewfinder
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 20.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(CharcoalText.copy(alpha = 0.82f))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = if (step == 1) "ALIGN FRONT OF PACK" else "ALIGN NUTRITION PANEL",
                    fontSize = 11.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                    letterSpacing = 1.sp,
                    color = Color.White
                )
            }
        }
    }
}
