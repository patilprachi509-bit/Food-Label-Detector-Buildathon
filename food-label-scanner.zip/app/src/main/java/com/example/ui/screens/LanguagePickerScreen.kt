package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BotanicalAccent
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.CondensedDisplayFont

@Composable
fun LanguagePickerScreen(
    onLanguageSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize()
    ) {
        // Main content in center
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Choose your language",
                fontFamily = CondensedDisplayFont,
                fontWeight = FontWeight.Bold,
                fontSize = 32.sp,
                lineHeight = 36.sp,
                color = CharcoalText,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "अपनी भाषा चुनें",
                fontWeight = FontWeight.Bold,
                fontSize = 28.sp,
                lineHeight = 32.sp,
                color = CharcoalText,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(48.dp))

            // English Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .border(1.5.dp, CharcoalText, RoundedCornerShape(32.dp))
                    .clickable { onLanguageSelected("en") }
                    .testTag("english_lang_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "English",
                    fontFamily = CondensedDisplayFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp,
                    color = CharcoalText
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Hindi Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .border(1.5.dp, CharcoalText, RoundedCornerShape(32.dp))
                    .clickable { onLanguageSelected("hi") }
                    .testTag("hindi_lang_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "हिन्दी",
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp,
                    color = CharcoalText
                )
            }
        }

        // Botanical Accent at bottom-right corner
        BotanicalAccent(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFFC4BCB0)
        )
    }
}
