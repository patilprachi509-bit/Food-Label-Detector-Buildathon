package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CreamBackground = Color(0xFFF9F7F2)
val CreamSurface = Color(0xFFFAF7F0)
val TerracottaAccent = Color(0xFFC4522E)
val CharcoalText = Color(0xFF2B2B26)
val CharcoalMuted = Color(0xFF6B6A64)
val ProgressInactive = Color(0x1A2B2B26)
val DarkShutterBorder = Color(0xFF2B2B26)
val CardBackground = Color(0xFFFFFFFF)

