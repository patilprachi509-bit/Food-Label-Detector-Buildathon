package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CharcoalMuted
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.CondensedDisplayFont
import com.example.ui.theme.TerracottaAccent

@Composable
fun LowConfidenceScreen(
    userLanguage: String,
    onRescanFront: () -> Unit,
    onRescanPanel: () -> Unit,
    onContinueAnyway: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isHindi = userLanguage == "hi"

    val title = if (isHindi) "लेबल को स्पष्ट रूप से नहीं पढ़ा जा सका" else "COULD NOT CLEARLY READ LABEL"
    val subtitle = if (isHindi) "स्कैन किया गया हिस्सा धुंधला है या पोषण तालिका अधूरी है। कृपया फिर से प्रयास करें।"
    else "The scanned image was blurry or missing key nutrition details. Please try scanning again."

    val rescanFrontText = if (isHindi) "अगला हिस्सा फिर से स्कैन करें" else "RESCAN FRONT OF PACK"
    val rescanPanelText = if (isHindi) "पोषण तालिका फिर से स्कैन करें" else "RESCAN NUTRITION PANEL"
    val continueText = if (isHindi) "मैन्युअल रूप से जारी रखें" else "CONTINUE WITH EXTRACTED VALUES"

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Warning Icon Badge
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(Color(0xFFF3E7E0)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Warning",
                tint = TerracottaAccent,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = title,
            fontFamily = CondensedDisplayFont,
            fontWeight = FontWeight.Black,
            fontSize = 28.sp,
            lineHeight = 32.sp,
            color = CharcoalText,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = subtitle,
            fontSize = 15.sp,
            color = CharcoalMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(40.dp))

        // Option 1: Rescan Front
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(TerracottaAccent)
                .clickable { onRescanFront() }
                .testTag("rescan_front_button"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = rescanFrontText,
                fontFamily = CondensedDisplayFont,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Option 2: Rescan Panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(28.dp))
                .border(1.5.dp, TerracottaAccent, RoundedCornerShape(28.dp))
                .clickable { onRescanPanel() }
                .testTag("rescan_panel_button"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = rescanPanelText,
                fontFamily = CondensedDisplayFont,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = TerracottaAccent
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Option 3: Continue anyway
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clickable { onContinueAnyway() },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = continueText,
                fontFamily = CondensedDisplayFont,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = CharcoalText
            )
        }
    }
}
