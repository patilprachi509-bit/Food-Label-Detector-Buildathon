package com.example.network

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.example.data.FoodLabelExtraction
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiExtractionService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val extractionAdapter = moshi.adapter(FoodLabelExtraction::class.java)

    suspend fun extractFoodLabelData(
        frontBitmap: Bitmap,
        panelBitmap: Bitmap
    ): Result<FoodLabelExtraction> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // Return fallback mock data if API key is not configured
            return@withContext Result.success(getFallbackData())
        }

        try {
            val frontBase64 = bitmapToBase64(frontBitmap)
            val panelBase64 = bitmapToBase64(panelBitmap)

            val promptText = """
                You are an expert food label parsing AI. Analyze the two images provided:
                Image 1: Front of the pack (product name, brand, claims).
                Image 2: Ingredients & Nutrition facts panel.

                Extract structured JSON matching EXACTLY this JSON structure:
                {
                  "front_of_pack": {
                    "claims": ["string"],
                    "brand_name": "string",
                    "product_name": "string"
                  },
                  "ingredients": {
                    "raw_list": ["string"],
                    "order_index": true,
                    "detected_language": "english"
                  },
                  "nutrition": {
                    "serving_size": "string",
                    "energy_kcal": 0.0,
                    "total_fat_g": 0.0,
                    "saturated_fat_g": 0.0,
                    "trans_fat_g": null,
                    "sugar_g": 0.0,
                    "sodium_mg": 0.0,
                    "protein_g": 0.0
                  },
                  "extraction_confidence": "high"
                }

                RULES:
                1. NORMALIZE NUTRITION VALUES to a consistent PER-100G basis. Calculate per 100g numbers if the panel is written per-serving.
                2. trans_fat_g is NULLABLE. If trans fat is not listed on the panel, set trans_fat_g to null.
                3. extraction_confidence must be "high", "medium", or "low". Use "low" if key panels are missing, unreadable, or blurry.
                4. Respond ONLY with valid JSON.
            """.trimIndent()

            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", promptText))
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", frontBase64)
                                })
                            })
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", panelBase64)
                                })
                            })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.1)
                })
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
            val body = requestJson.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP ${response.code}: $responseString"))
            }

            val parsedJson = JSONObject(responseString)
            val candidates = parsedJson.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text") ?: ""

            val cleanedJson = text.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()

            val extraction = extractionAdapter.fromJson(cleanedJson)
                ?: return@withContext Result.failure(Exception("Failed to parse JSON into FoodLabelExtraction"))

            Result.success(extraction)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        val byteArray = stream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }

    fun getFallbackData(): FoodLabelExtraction {
        return FoodLabelExtraction(
            front_of_pack = com.example.data.FrontOfPackData(
                claims = listOf("Plant Protein", "40% Less Fat", "Gluten Free"),
                brand_name = "Smoky Barbeque",
                product_name = "Baked Chickpea Puffs"
            ),
            ingredients = com.example.data.IngredientsData(
                raw_list = listOf(
                    "Chickpea flour", "Rice flour", "Sunflower oil", "Corn starch",
                    "Tapioca starch", "Sugar", "Smoky barbeque seasoning", "Salt",
                    "Spices", "Yeast extract", "Paprika extract"
                ),
                order_index = true,
                detected_language = "english"
            ),
            nutrition = com.example.data.NutritionData(
                serving_size = "28g (1 oz)",
                energy_kcal = 428.0, // normalized per 100g
                total_fat_g = 14.3,
                saturated_fat_g = 1.8,
                trans_fat_g = null, // Indian panel omitted trans fat
                sugar_g = 7.1,
                sodium_mg = 750.0,
                protein_g = 10.7
            ),
            extraction_confidence = "high"
        )
    }
}
