package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.screens.CaptureFrontScreen
import com.example.ui.screens.CapturePanelScreen
import com.example.ui.screens.LanguagePickerScreen
import com.example.ui.screens.LowConfidenceScreen
import com.example.ui.screens.PersonalizationScreen
import com.example.ui.screens.ProcessingScreen
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.FoodLabelScannerTheme
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AppViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            FoodLabelScannerTheme {
                val currentScreen by viewModel.currentScreen.collectAsState()
                val userLanguage by viewModel.userLanguage.collectAsState()
                val extractionResult by viewModel.extractionResult.collectAsState()

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(CreamBackground)
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentScreen) {
                            AppScreen.LANGUAGE_PICKER -> {
                                LanguagePickerScreen(
                                    onLanguageSelected = { lang ->
                                        viewModel.selectLanguage(lang)
                                    }
                                )
                            }

                            AppScreen.CAPTURE_FRONT -> {
                                CaptureFrontScreen(
                                    userLanguage = userLanguage ?: "en",
                                    onFrontCaptured = { bitmap ->
                                        viewModel.setFrontPhoto(bitmap)
                                    }
                                )
                            }

                            AppScreen.CAPTURE_PANEL -> {
                                CapturePanelScreen(
                                    userLanguage = userLanguage ?: "en",
                                    onPanelCaptured = { bitmap ->
                                        viewModel.setPanelPhoto(bitmap)
                                    }
                                )
                            }

                            AppScreen.PROCESSING -> {
                                ProcessingScreen(
                                    userLanguage = userLanguage ?: "en"
                                )
                            }

                            AppScreen.LOW_CONFIDENCE -> {
                                LowConfidenceScreen(
                                    userLanguage = userLanguage ?: "en",
                                    onRescanFront = { viewModel.restartScanFlow() },
                                    onRescanPanel = { viewModel.rescanPanel() },
                                    onContinueAnyway = {
                                        viewModel.processPhotos()
                                    }
                                )
                            }

                            AppScreen.PERSONALIZATION -> {
                                extractionResult?.let { extraction ->
                                    PersonalizationScreen(
                                        userLanguage = userLanguage ?: "en",
                                        extraction = extraction,
                                        onScanNext = { viewModel.restartScanFlow() },
                                        onChangeLanguage = { viewModel.resetLanguage() }
                                    )
                                } ?: ProcessingScreen(userLanguage = userLanguage ?: "en")
                            }
                        }
                    }
                }
            }
        }
    }
}
