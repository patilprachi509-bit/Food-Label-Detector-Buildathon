package com.example.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FoodLabelExtraction
import com.example.data.UserPreferences
import com.example.network.GeminiExtractionService
import com.example.ui.components.SamplePackGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

enum class AppScreen {
    LANGUAGE_PICKER,  // Screen 0
    CAPTURE_FRONT,    // Screen 1
    CAPTURE_PANEL,    // Screen 2
    PROCESSING,       // Screen 4
    LOW_CONFIDENCE,   // Branch 3
    PERSONALIZATION   // Branch 2
}

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val userPreferences = UserPreferences(application)
    private val extractionService = GeminiExtractionService()

    private val _userLanguage = MutableStateFlow<String?>(null)
    val userLanguage: StateFlow<String?> = _userLanguage.asStateFlow()

    private val _currentScreen = MutableStateFlow(AppScreen.LANGUAGE_PICKER)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _frontBitmap = MutableStateFlow<Bitmap?>(null)
    val frontBitmap: StateFlow<Bitmap?> = _frontBitmap.asStateFlow()

    private val _panelBitmap = MutableStateFlow<Bitmap?>(null)
    val panelBitmap: StateFlow<Bitmap?> = _panelBitmap.asStateFlow()

    private val _extractionResult = MutableStateFlow<FoodLabelExtraction?>(null)
    val extractionResult: StateFlow<FoodLabelExtraction?> = _extractionResult.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    init {
        viewModelScope.launch {
            val savedLang = userPreferences.userLanguage.first()
            _userLanguage.value = savedLang
            if (savedLang.isNullOrEmpty()) {
                _currentScreen.value = AppScreen.LANGUAGE_PICKER
            } else {
                _currentScreen.value = AppScreen.CAPTURE_FRONT
            }
        }
    }

    fun selectLanguage(languageCode: String) {
        viewModelScope.launch {
            userPreferences.saveUserLanguage(languageCode)
            _userLanguage.value = languageCode
            _currentScreen.value = AppScreen.CAPTURE_FRONT
        }
    }

    fun resetLanguage() {
        viewModelScope.launch {
            userPreferences.clearUserLanguage()
            _userLanguage.value = null
            _currentScreen.value = AppScreen.LANGUAGE_PICKER
        }
    }

    fun setFrontPhoto(bitmap: Bitmap) {
        _frontBitmap.value = bitmap
        _currentScreen.value = AppScreen.CAPTURE_PANEL
    }

    fun setPanelPhoto(bitmap: Bitmap) {
        _panelBitmap.value = bitmap
        _currentScreen.value = AppScreen.PROCESSING
        processPhotos()
    }

    fun processPhotos() {
        val front = _frontBitmap.value ?: SamplePackGenerator.createFrontPackBitmap()
        val panel = _panelBitmap.value ?: SamplePackGenerator.createPanelPackBitmap()

        viewModelScope.launch {
            _currentScreen.value = AppScreen.PROCESSING
            _errorMessage.value = null

            val result = extractionService.extractFoodLabelData(front, panel)
            result.onSuccess { extraction ->
                _extractionResult.value = extraction
                if (extraction.extraction_confidence.equals("low", ignoreCase = true)) {
                    _currentScreen.value = AppScreen.LOW_CONFIDENCE
                } else {
                    _currentScreen.value = AppScreen.PERSONALIZATION
                }
            }.onFailure { error ->
                _errorMessage.value = error.message
                // Fallback to extraction data with low confidence state if network error
                val fallback = extractionService.getFallbackData()
                _extractionResult.value = fallback
                _currentScreen.value = AppScreen.PERSONALIZATION
            }
        }
    }

    fun restartScanFlow() {
        _frontBitmap.value = null
        _panelBitmap.value = null
        _extractionResult.value = null
        _currentScreen.value = AppScreen.CAPTURE_FRONT
    }

    fun rescanPanel() {
        _panelBitmap.value = null
        _currentScreen.value = AppScreen.CAPTURE_PANEL
    }

    fun forceLowConfidenceState() {
        val current = _extractionResult.value ?: extractionService.getFallbackData()
        _extractionResult.value = current.copy(extraction_confidence = "low")
        _currentScreen.value = AppScreen.LOW_CONFIDENCE
    }
}
