package com.example.data

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class FrontOfPackData(
    @Json(name = "claims") val claims: List<String> = emptyList(),
    @Json(name = "brand_name") val brand_name: String = "",
    @Json(name = "product_name") val product_name: String = ""
)

@JsonClass(generateAdapter = true)
data class IngredientsData(
    @Json(name = "raw_list") val raw_list: List<String> = emptyList(),
    @Json(name = "order_index") val order_index: Boolean = true,
    @Json(name = "detected_language") val detected_language: String = "english"
)

@JsonClass(generateAdapter = true)
data class NutritionData(
    @Json(name = "serving_size") val serving_size: String = "",
    @Json(name = "energy_kcal") val energy_kcal: Double = 0.0,
    @Json(name = "total_fat_g") val total_fat_g: Double = 0.0,
    @Json(name = "saturated_fat_g") val saturated_fat_g: Double = 0.0,
    @Json(name = "trans_fat_g") val trans_fat_g: Double? = null,
    @Json(name = "sugar_g") val sugar_g: Double = 0.0,
    @Json(name = "sodium_mg") val sodium_mg: Double = 0.0,
    @Json(name = "protein_g") val protein_g: Double = 0.0
)

@JsonClass(generateAdapter = true)
data class FoodLabelExtraction(
    @Json(name = "front_of_pack") val front_of_pack: FrontOfPackData = FrontOfPackData(),
    @Json(name = "ingredients") val ingredients: IngredientsData = IngredientsData(),
    @Json(name = "nutrition") val nutrition: NutritionData = NutritionData(),
    @Json(name = "extraction_confidence") val extraction_confidence: String = "high"
)
