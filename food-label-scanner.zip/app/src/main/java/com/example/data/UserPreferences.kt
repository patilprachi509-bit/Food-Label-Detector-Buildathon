package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "user_settings")

class UserPreferences(private val context: Context) {

    companion object {
        val KEY_USER_LANGUAGE = stringPreferencesKey("user_language")
    }

    val userLanguage: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[KEY_USER_LANGUAGE]
    }

    suspend fun saveUserLanguage(languageCode: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_USER_LANGUAGE] = languageCode
        }
    }

    suspend fun clearUserLanguage() {
        context.dataStore.edit { preferences ->
            preferences.remove(KEY_USER_LANGUAGE)
        }
    }
}
